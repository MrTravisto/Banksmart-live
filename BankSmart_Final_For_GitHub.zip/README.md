# BankSmart

Ready-to-upload GitHub Pages version.
Just upload these files to your repository and enable Pages.